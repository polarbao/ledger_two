# AI 编码任务拆分与提示词模板 v0.3

## 1. 使用原则

不要让 AI 一次性实现整个系统。必须按模块切片，每次只实现一个小目标，并要求 AI：

1. 先阅读相关文档。
2. 说明计划。
3. 修改代码。
4. 运行测试。
5. 输出变更摘要。

## 2. 推荐任务顺序

### Task 01：初始化工程结构

```text
请阅读 docs/00_DOCUMENT_INDEX.md、docs/13_DEMO_SCOPE_LOCK.md、docs/14_BACKEND_MODULE_SPEC.md。
创建 backend Go 工程基础结构：cmd/server/main.go、internal/config、internal/db、internal/http/router。
要求：服务可启动，提供 GET /api/healthz 返回 {success:true,data:{status:"ok"}}。
不要实现业务模块。
完成后运行 go test ./...。
```

### Task 02：数据库迁移

```text
请阅读 docs/07_DATABASE_API.md 和 docs/14_BACKEND_MODULE_SPEC.md。
创建 SQLite migration：users、categories、tags、accounts、transactions、transaction_tags、transaction_splits、settlements、audit_logs、app_settings。
金额使用整数分。
增加必要索引。
提供 migration 执行入口。
完成后用 sqlite3 验证表结构。
```

### Task 03：初始化与用户模块

```text
实现 /api/init/status 与 /api/init/setup。
setup 必须创建两个用户、默认分类、默认账户，并写 initialized=true。
密码必须 hash，不能明文保存。
补充单元测试：首次允许 setup，完成后不允许重复 setup。
```

### Task 04：登录认证

```text
实现 /api/auth/login、/api/auth/logout、/api/auth/me。
使用 HttpOnly Cookie session。
实现 auth middleware。
补充测试：未登录返回 401，登录后 me 返回当前用户。
```

### Task 05：普通账单 CRUD

```text
实现 expense/income 普通账单 CRUD。
要求：创建、列表、详情、编辑、软删除。
实现 private/partner_readable 可见性规则。
金额不能为 0 或负数。
修改和删除写 audit_logs。
补充权限测试。
```

### Task 06：共同支出

```text
实现 POST /api/shared-expenses。
Demo 只实现 split_method equal 和 payer_only。
equal 的奇数分给付款人多承担 1 分。
写入 transactions 和 transaction_splits。
补充测试：200 元平摊、100.01 元平摊、payer_only。
```

### Task 07：结算中心

```text
实现 GET /api/settlements/balance 与 POST /api/settlements。
结算必须写 settlements 表和 transactions.type=settlement 流水。
不得修改历史 shared_expense。
补充测试：A 付 200、B 付 80、B 结算 60 后结清。
```

### Task 08：Dashboard 与统计

```text
实现 /api/dashboard。
返回本月总支出、收入、我支付、对方支付、待结算、最近流水、分类统计、标签统计、成员统计。
统计不包含 deleted 数据。
结算记录不进入消费统计。
```

### Task 09：前端初始化

```text
请阅读 docs/15_FRONTEND_MODULE_SPEC.md。
创建 React + TypeScript + Vite 前端工程结构。
实现 api/client.ts、路由、AppShell、LoginPage、InitPage。
不要实现复杂 UI，先保证流程跑通。
```

### Task 10：前端流水与记一笔

```text
实现 DashboardPage、TransactionsPage、TransactionFormDrawer、TransactionCard/Table。
金额输入以元为单位，提交前转分。
保存成功后刷新列表和 dashboard。
```

### Task 11：前端结算中心

```text
实现 SettlementPage，包括当前谁欠谁、计算明细、结算历史、生成结算记录弹窗。
```

### Task 12：Docker 与部署

```text
完善 Dockerfile 和 docker-compose.yml。
要求：本地 docker compose up -d --build 后可以访问前端和 API。
SQLite 数据挂载到 ./data。
```

## 3. Codex 工作提示词模板

### 3.1 每次开始任务

```text
你是 LedgerTwo 项目的高级全栈工程师。
请先阅读 docs/00_DOCUMENT_INDEX.md、docs/13_DEMO_SCOPE_LOCK.md，以及本任务相关文档。
严格遵守 Demo 范围，不要实现文档之外的功能。
完成后请运行对应测试并给出变更摘要。
```

### 3.2 后端任务补充约束

```text
后端要求：
- Go 1.22+
- SQLite
- 金额用 int64 分
- handler 只处理 HTTP，业务放 service，SQL 放 repo
- 统一响应结构
- 错误码使用文档定义
- 权限规则必须测试
```

### 3.3 前端任务补充约束

```text
前端要求：
- React + TypeScript + Vite
- TanStack Query 管服务端状态
- Zustand 只管 UI 状态
- React Hook Form + Zod 做表单
- 金额输入元，API 提交分
- 移动端优先，桌面端增强
```

## 4. AI 输出验收格式

每次 AI 完成任务，必须输出：

```text
完成内容：
- ...

修改文件：
- ...

验证命令：
- ...

未完成/风险：
- ...

下一步建议：
- ...
```
