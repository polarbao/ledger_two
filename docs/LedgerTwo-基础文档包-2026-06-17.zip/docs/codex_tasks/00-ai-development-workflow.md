# AI 开发工作流

## 1. 通用提示词模板

```text
你是 LedgerTwo 项目的高级全栈工程师。
当前项目已完成 docs/18_POST_DEMO_AI_CODING_TASKS.md 中 Task01-Task30，并进入 Foundation before v1.1 阶段。

请先阅读：
- docs/00_DOCUMENT_INDEX.md
- docs/prd/11-foundation-framework-before-v1.1.md
- docs/tech/13-foundation-framework-before-v1.1.md
- docs/codex_tasks/README.md
- docs/codex_tasks/01-repository-code-style.md
- 本任务指定文档

执行规则：
1. 先输出实现计划和预计修改文件，等待确认。
2. 只实现当前任务，不实现未审核 v1.1 业务。
3. 保持金额 int64 cents。
4. 后端是权限、结算、统计的唯一可信来源。
5. 不修改历史 migration。
6. 完成后运行测试和构建。
7. 输出完成内容、修改文件、验证命令、未完成/风险、下一步建议。
```

## 2. 任务拆分原则

每个 AI 任务必须满足：

1. 单一目标。
2. 修改文件数量可控。
3. 有明确禁止事项。
4. 有测试要求。
5. 有验收标准。
6. 不依赖未审核业务需求。

## 3. 修改前检查

AI 开始修改前必须回答：

```text
本任务目标：
计划修改文件：
不修改文件：
风险点：
需要运行的验证命令：
```

## 4. 修改后输出

```text
完成内容：
- ...

修改文件：
- ...

验证命令：
- ...

未完成/风险：
- ...

下一步建议：
- ...
```

## 5. 小步提交规则

推荐提交粒度：

- 一个 Foundation Task 一个分支。
- 一个分支可以有多个小 commit。
- 不把 docs、backend、frontend、migration 的大范围变更混到一个 commit。
- 大改前先提交文档和测试。

## 6. 回退策略

如果任务失败：

1. 保留失败原因。
2. 不继续扩大修改范围。
3. 输出已修改文件和建议回滚方式。
4. 不强行删除测试。
