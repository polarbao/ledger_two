# PRD / Tech 文档校验报告

校验对象：

- `docs/prd/` 下模块化 PRD。
- `docs/ui/` 下 UI 交互文档。
- `docs/tech/` 下技术设计与实现文档。

## 1. 总体结论

当前文档已经形成了比较完整的模块化结构，可以支持后续按模块进行产品设计、AI 辅助开发和人工评审。

文档结构已经覆盖：

- 产品路线。
- 账本与成员。
- 账单系统。
- 共同支出、分摊、结算。
- 分类、标签、账户。
- 统计分析。
- 导入导出。
- 附件小票。
- 预算提醒。
- 跨端计划。
- UI 页面交互。
- 后端、前端、数据库、算法、部署、测试。

整体无明显方向性错误，但存在几个需要后续持续关注的逻辑点。

## 2. 已解决的问题

### 2.1 文档结构问题

已从单一长文档拆分为：

```text
docs/prd/
docs/ui/
docs/tech/
```

并按照业务模块拆分，适合 AI 按模块阅读和实现。

### 2.2 Demo 与后续版本边界

PRD 中已经明确：

- v0.1 Demo 只做双人、单账本、核心记账和结算。
- v0.2 优先稳定性和数据安全。
- v0.3 再提升录入效率。
- v0.4 做导入附件。
- v0.5 做多账本和多成员。
- v0.6 做 PWA 和跨端。

这一点避免 AI 或开发者过早实现多人、多账本、OCR、预算等复杂功能。

### 2.3 核心业务规则

文档已经多处强调：

- 金额使用 int64 cents。
- 删除使用 soft delete。
- 结算不修改历史账单。
- settlement 不进入消费统计。
- private 账单不能泄露给对方。
- 前端不做最终结算计算。

这些规则是记账项目最关键的业务约束。

## 3. 发现的潜在缺陷与建议

### 3.1 结算公式需要统一表述

`docs/tech/05-settlement-algorithm.md` 中已经给出推荐公式：

```text
raw_net = paid_amount - share_amount
settlement_net = received_settlement - paid_settlement
final_net = raw_net - settlement_net
```

这是当前最清晰的表达。

建议后续所有文档都统一采用这个公式，避免再使用其他方向相反的表达，例如：

```text
net = paid - share - paidSettlement + receivedSettlement
```

因为不同视角容易导致正负号混乱。

结论：轻微风险，已在算法文档中修正为推荐表达。

### 3.2 多账本与当前单账本之间需要迁移方案

PRD 已规划 v0.5 引入 `ledgers` 和 `ledger_members`，但当前 Demo 表结构可能还没有 `ledger_id`。

建议在 v0.2 或 v0.3 提前做一个兼容设计：

- 即使 UI 仍只显示一个账本，也可以先创建 default ledger。
- transactions 可预留 `ledger_id`。
- 后续多账本迁移会更平滑。

结论：中等风险。若 Demo 已无 ledger_id，后续需要 migration 补齐。

### 3.3 认证方案需要为跨端预留但不要过早实现

当前 Web 推荐 Cookie Session，跨端文档中预留 Token 认证。

建议：

- v0.2-v0.4 仍然只实现 Cookie Session。
- Auth service 设计时不要把认证逻辑写死在浏览器环境。
- v0.6 之后再考虑 Token。

结论：无立即问题，但需要防止过早复杂化。

### 3.4 附件备份需要与数据库备份联动

PRD 和技术文档已说明附件不存 BLOB，而是存 NAS 本地文件。

潜在问题：如果只备份 SQLite，不备份 uploads，则附件会丢失。

建议：

- 备份文档中持续强调 data、backups、uploads 都要备份。
- JSON 导出中记录附件元数据，但不内嵌附件文件。
- 后续做恢复时校验附件缺失情况。

结论：中等风险，已经在 NAS 部署和附件文档中提示。

### 3.5 预算、提醒、OCR 不应进入近期开发

PRD 已列入长期规划，但如果 AI 读取文档时没有明确版本范围，可能会提前实现。

建议：

- 每次 AI 开发任务都要求先阅读 `docs/prd/00-product-roadmap.md`。
- v0.2 阶段只做稳定性，不做预算、OCR、多成员。

结论：需求膨胀风险，需要通过任务提示词控制。

### 3.6 统计口径需要继续细化

当前文档已经说明 settlement 不进入消费统计，但后续还需要明确：

- refund 是否抵扣支出。
- transfer 是否完全排除统计。
- income 是否单独统计。
- deleted 是否永远排除。
- shared_expense 按付款人统计还是按承担人统计。

建议在实现统计模块前补充一份更细的统计口径文档，或扩展 `docs/prd/05-analytics-report.md` 与 `docs/tech/04-database-api.md`。

结论：中等风险，统计模块开发前必须补充。

### 3.7 恢复备份功能需要谨慎实现

技术文档建议 v0.2 先提供备份和下载，恢复流程先写文档。

这是合理的。恢复功能一旦做错会覆盖真实数据。

建议：

- v0.2 不做 UI 恢复。
- 先做手动恢复文档。
- v1.0 前再考虑安全恢复 UI。

结论：无缺陷，当前策略正确。

## 4. 对 AI 开发的适用性判断

当前模块化文档适合 AI 按以下方式开发：

```text
1. 先读 docs/README.md。
2. 再读对应 PRD 模块。
3. 再读对应 UI 模块。
4. 再读对应 Tech 模块。
5. 只实现一个模块或一个任务。
```

不建议让 AI 一次性读取全部文档并实现整个项目。

推荐提示词：

```text
请只实现【模块名称】。
先阅读 docs/prd/xx.md、docs/ui/xx.md、docs/tech/xx.md。
输出实现计划并等待确认。
不要实现文档之外的功能。
```

## 5. 建议后续补充的文档

优先级 P0：

- `docs/tech/10-error-codes.md`：统一错误码。
- `docs/tech/11-security-auth.md`：认证、安全、权限细节。
- `docs/tech/12-statistics-caliber.md`：统计口径。

优先级 P1：

- `docs/prd/10-error-empty-states.md`：空状态和异常状态。
- `docs/prd/11-admin-data-safety.md`：管理员与数据安全。

## 6. 最终结论

当前 PRD / UI / Tech 文档无明显致命缺陷，可以作为后续模块化开发基础。

最需要持续关注的 3 个点：

1. 结算公式与正负号必须统一。
2. 多账本迁移需要提前预留 ledger_id 或 default ledger 策略。
3. 统计口径在正式开发前必须进一步细化。

建议下一步进入 v0.2 稳定版开发：审计日志、备份导出、错误码、权限回归、结算测试。
